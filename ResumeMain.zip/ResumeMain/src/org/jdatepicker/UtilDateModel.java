package org.jdatepicker;

public class UtilDateModel {

}
